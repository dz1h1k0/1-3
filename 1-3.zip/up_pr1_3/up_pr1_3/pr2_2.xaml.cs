﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace up_pr1_3
{
    /// <summary>
    /// Логика взаимодействия для pr2_2.xaml
    /// </summary>
    public partial class pr2_2 : Window
    {
        public pr2_2()
        {
            InitializeComponent();
            AddRectangles1();
            AddRectangles2();
        }
        private void AddRectangles1()
        {
            for (int i = 0; i < 10; i++)
            {
                var rect = new Rectangle
                {
                    Width = 40,
                    Height = 40,
                    Fill = System.Windows.Media.Brushes.LightBlue,
                    //Stroke = System.Windows.Media.Brushes.Black,
                    StrokeThickness = 1,
                    Margin = new Thickness(5),
                };
                wrapPanel1.Children.Add(rect);
            }
        }
        private void AddRectangles2()
        {
            for (int i = 0; i < 10; i++)
            {
                var rect = new Rectangle
                {
                    Width = 40,
                    Height = 40,
                    Fill = System.Windows.Media.Brushes.LightBlue,
                    //Stroke = System.Windows.Media.Brushes.Black,
                    StrokeThickness = 1,
                    Margin = new Thickness(5),
                };
                wrapPanel2.Children.Add(rect);
            }
        }
    }
}
