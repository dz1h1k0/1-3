﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Forms;


namespace up_pr1_3
{
    /// <summary>
    /// Логика взаимодействия для pr3.xaml
    /// </summary>
    public partial class pr3 : Window
    {
        public pr3()
        {
            InitializeComponent();
        }

        private void ColorPicker_SelectedColorChanged(object sender, RoutedPropertyChangedEventArgs<Color?> e)
        {
            if (menuColorPicker.SelectedColor.HasValue)
            {
                StatusBarik.Background = new SolidColorBrush(menuColorPicker.SelectedColor.Value);
            }
        }

        private void About_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Разработчик: Иван Иванов\nEmail: developer@example.com\nВерсия: 1.0", "О программе");
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            pr3_2 pr3_2 = new pr3_2();
            pr3_2.Show();
        }
    }
}
