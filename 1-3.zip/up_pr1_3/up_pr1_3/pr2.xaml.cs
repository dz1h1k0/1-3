﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace up_pr1_3
{
    /// <summary>
    /// Логика взаимодействия для pr2.xaml
    /// </summary>
    public partial class pr2 : Window
    {
        public pr2()
        {
            InitializeComponent();
            AddRectangles();
        }
        private void AddRectangles()
        {
            var rect1 = new Rectangle
            {
                Width = 100,
                Height = 100,
                Fill = System.Windows.Media.Brushes.Yellow,
                //Stroke = System.Windows.Media.Brushes.Black,
                StrokeThickness = 1,
                Margin = new Thickness(5),
            };
            wrapPanel.Children.Add(rect1);
            var rect2 = new Rectangle
            {
                Width = 100,
                Height = 100,
                Fill = System.Windows.Media.Brushes.Red,
                //Stroke = System.Windows.Media.Brushes.Black,
                StrokeThickness = 1,
                Margin = new Thickness(5),
            };
            wrapPanel.Children.Add(rect2);
            var rect3 = new Rectangle
            {
                Width = 100,
                Height = 100,
                Fill = System.Windows.Media.Brushes.Green,
                //Stroke = System.Windows.Media.Brushes.Black,
                StrokeThickness = 1,
                Margin = new Thickness(5),
            };
            wrapPanel.Children.Add(rect3);
            var rect4 = new Rectangle
            {
                Width = 100,
                Height = 100,
                Fill = System.Windows.Media.Brushes.Blue,
                //Stroke = System.Windows.Media.Brushes.Black,
                StrokeThickness = 1,
                Margin = new Thickness(5),
            };
            wrapPanel.Children.Add(rect4);
            var rect5 = new Rectangle
            {
                Width = 100,
                Height = 100,
                Fill = System.Windows.Media.Brushes.Gray,
                //Stroke = System.Windows.Media.Brushes.Black,
                StrokeThickness = 1,
                Margin = new Thickness(5),
            };
            wrapPanel.Children.Add(rect5);
            var rect6 = new Rectangle
            {
                Width = 100,
                Height = 100,
                Fill = System.Windows.Media.Brushes.LightBlue,
                //Stroke = System.Windows.Media.Brushes.Black,
                StrokeThickness = 1,
                Margin = new Thickness(5),
            };
            wrapPanel.Children.Add(rect6);

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            pr2_2 pr2_2 = new pr2_2();
            pr2_2.Show();
        }
    }
}
