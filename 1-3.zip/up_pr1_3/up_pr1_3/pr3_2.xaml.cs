﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace up_pr1_3
{
    /// <summary>
    /// Логика взаимодействия для pr3_2.xaml
    /// </summary>
    public partial class pr3_2 : Window
    {
        private Point lastPoint;
        private bool isDrawing = false;
        private List<Ellipse> drawnShapes = new List<Ellipse>();
        public pr3_2()
        {
            InitializeComponent();
        }
        private void DrawingCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (DrawMode.IsChecked == true)
            {
                isDrawing = true;
                lastPoint = e.GetPosition(DrawingCanvas);
            }
            else if (DeleteMode.IsChecked == true)
            {
                DeleteShape(e.GetPosition(DrawingCanvas));
            }
        }

        private void DrawingCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDrawing && DrawMode.IsChecked == true)
            {
                Point currentPoint = e.GetPosition(DrawingCanvas);

                Line line = new Line
                {
                    Stroke = GetSelectedBrush(),
                    StrokeThickness = BrushSizeSlider.Value,
                    X1 = lastPoint.X,
                    Y1 = lastPoint.Y,
                    X2 = currentPoint.X,
                    Y2 = currentPoint.Y
                };

                DrawingCanvas.Children.Add(line);
                lastPoint = currentPoint;
            }
        }

        private void DrawingCanvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDrawing = false;
        }

        private SolidColorBrush GetSelectedBrush()
        {
            var selectedItem = ColorComboBox.SelectedItem as ComboBoxItem;
            string colorName = selectedItem?.Tag as string ?? "Black";
            return new SolidColorBrush((Color)ColorConverter.ConvertFromString(colorName));
        }

        private void DeleteShape(Point point)
        {
            foreach (var shape in DrawingCanvas.Children)
            {
                if (shape is Shape s)
                {
                    Rect bounds = VisualTreeHelper.GetDescendantBounds(s);
                    if (bounds.Contains(point))
                    {
                        DrawingCanvas.Children.Remove(s);
                        return;
                    }
                }
            }
        }
        private void ClearCanvas_Click(object sender, RoutedEventArgs e)
        {
            DrawingCanvas.Children.Clear();
        }
    }
}
