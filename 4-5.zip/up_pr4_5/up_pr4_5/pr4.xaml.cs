﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace up_pr4_5
{
    /// <summary>
    /// Логика взаимодействия для pr4.xaml
    /// </summary>
    public partial class pr4 : Window
    {
        public pr4()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            pr4_2 pr4_2 = new pr4_2();
            pr4_2.Show();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            pr4_4 pr4_4 = new pr4_4();
            pr4_4.Show();
        }
    }
}
